
import os

class FileManager:
    def __init__(self, base_directory):
        self.base_directory = base_directory

    def create_file(self, file_name, content=""):
        file_path = os.path.join(self.base_directory, file_name)
        with open(file_path, 'w') as file:
            file.write(content)
        return file_path

    def read_file(self, file_name):
        file_path = os.path.join(self.base_directory, file_name)
        with open(file_path, 'r') as file:
            return file.read()

    def delete_file(self, file_name):
        file_path = os.path.join(self.base_directory, file_name)
        if os.path.exists(file_path):
            os.remove(file_path)
            return True
        return False

    def list_files(self):
        return os.listdir(self.base_directory)
